import balance.Account;

public class run{
   public static void main(String[] args) {
       Account obj1 = new Account(5000000);
       obj1.display_balance();

   }
}