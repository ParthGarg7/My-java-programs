public class lab1_2{
    public static void main(String[] args){
        System.out.println("My Name is Parth Garg");
        System.out.println("My Sap ID is 500122496");
        System.out.println("My Address is Zenith boys hostel");
    }
}