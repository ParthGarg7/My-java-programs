public class lab1_3 
{
    public static void main(String[] args)
     {
        String name = "Parth Garg";
        String rollNumber = "R2142231540";
        String sapId = "500123456";
        String result = "Pass";

        System.out.println("********************************************");
        System.out.println("*             GRADE SHEET                  *");
        System.out.println("********************************************");
        System.out.println("* Name        : " + name + "                 *");
        System.out.println("* Roll Number : " + rollNumber + "                *");
        System.out.println("* SAP ID      : " + sapId + "                  *");
        System.out.println("* Result      : " + result + "                       *");
        System.out.println("********************************************");
    }
}
