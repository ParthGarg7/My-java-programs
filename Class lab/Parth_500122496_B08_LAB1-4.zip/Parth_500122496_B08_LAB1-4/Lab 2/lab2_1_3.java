public class lab2_1_3{
	public static void main(String[] args)
	{
		double b = Double.parseDouble(args[0]);
	    double h = Double.parseDouble(args[1]);
		System.out.println("Area is " + b*h*0.5);
	}
 }
